// Configure o convite oficial do Discord abaixo.
const DISCORD_INVITE = ""; // Exemplo: "https://discord.gg/seuconvite"

const toggle = document.getElementById("menuToggle");
const nav = document.getElementById("nav");
toggle.addEventListener("click", () => {
  const isOpen = nav.classList.toggle("open");
  toggle.setAttribute("aria-expanded", String(isOpen));
  toggle.textContent = isOpen ? "×" : "☰";
});
nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  nav.classList.remove("open");
  toggle.setAttribute("aria-expanded", "false");
  toggle.textContent = "☰";
}));
document.getElementById("year").textContent = new Date().getFullYear();

const discordLink = document.getElementById("discordLink");
const linkHint = document.getElementById("linkHint");
if (DISCORD_INVITE.trim()) {
  discordLink.href = DISCORD_INVITE;
  discordLink.target = "_blank";
  discordLink.rel = "noopener noreferrer";
  linkHint.textContent = "Você será direcionado ao convite oficial da comunidade.";
} else {
  discordLink.addEventListener("click", event => {
    event.preventDefault();
    linkHint.textContent = "Adicione o convite do Discord em script.js para ativar este botão.";
    linkHint.classList.add("hint-active");
  });
}
